``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19043.1466 (21H1/May2021Update)
Intel Core i5-1035G1 CPU 1.00GHz, 1 CPU, 8 logical and 4 physical cores
.NET SDK=6.0.100
  [Host]     : .NET 6.0.0 (6.0.21.52210), X64 RyuJIT
  DefaultJob : .NET 6.0.0 (6.0.21.52210), X64 RyuJIT


```
|                          Method |     Mean |    Error |   StdDev |   Median | Ratio | RatioSD | Rank | Completed Work Items | Lock Contentions |  Gen 0 | Allocated |
|-------------------------------- |---------:|---------:|---------:|---------:|------:|--------:|-----:|---------------------:|-----------------:|-------:|----------:|
| GetTaskConfigureAwaitFalseAsync | 16.00 μs | 0.543 μs | 1.523 μs | 15.57 μs |  0.96 |    0.22 |    1 |               1.0207 |           0.0008 | 0.2136 |     701 B |
|                         GetTask | 17.31 μs | 1.211 μs | 3.570 μs | 16.04 μs |  1.00 |    0.00 |    1 |               1.0367 |           0.0018 | 0.1831 |     647 B |
