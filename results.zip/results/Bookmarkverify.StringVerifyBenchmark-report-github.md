``` ini

BenchmarkDotNet=v0.13.1, OS=Windows 10.0.19043.1466 (21H1/May2021Update)
Intel Core i5-1035G1 CPU 1.00GHz, 1 CPU, 8 logical and 4 physical cores
.NET SDK=6.0.101
  [Host]     : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT
  DefaultJob : .NET 6.0.1 (6.0.121.56705), X64 RyuJIT


```
|          Method |        Mean |     Error |    StdDev | Ratio | Allocated native memory | Native memory leak |  Gen 0 | Allocated |
|---------------- |------------:|----------:|----------:|------:|------------------------:|-------------------:|-------:|----------:|
|      SpanVerify |    46.45 ns |  0.973 ns |  1.804 ns |  0.04 |                       - |                  - |      - |         - |
| SubStringVerify | 1,249.04 ns | 30.402 ns | 88.203 ns |  1.00 |                       - |                  - | 1.0185 |   3,200 B |
